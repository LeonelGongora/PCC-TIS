import java.io.*;
import java.net.*;
import java.util.Scanner;

public class servidor{
    static final int PUERTO = 12321;
    
    public servidor(){
        try{
            ServerSocket skServidor = new ServerSocket (PUERTO);
            Socket skCliente = skServidor.accept();
            
            DataInputStream in = new DataInputStream(skCliente.getInputStream());
            DataOutputStream out = new DataOutputStream(skCliente.getOutputStream());
            Scanner sc = new Scanner(System.in);
            
            out.writeUTF("Bienvenido al servidor/n " + "Ingrese su nombre: ");
            String nombCliente = in.readUTF();
            System.out.println (nombCliente);
            boolean bandera = true;
            
            while(bandera){
                String envio = sc.nextLine();
                out.writeUTF(envio);
                
                String mensaje = in.readUTF();
                System.out.println(nombCliente + ": " + mensaje);
                if(mensaje.equals("Bye")){
                    bandera = false;
                }
            }
            out.writeUTF("Hasta la proxima");
            bandera = true;
            System.out.println(nombCliente + " se desconecto");
            skCliente.close();
        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public static void main(String [] arg){
        new servidor();
    }
}