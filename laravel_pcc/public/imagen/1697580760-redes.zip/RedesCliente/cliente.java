import java.io.*;
import java.net.*;
import java.util.Scanner;

public class cliente{
    static final String HOST = "127.0.0.1";
    static final int PUERTO = 12321;
    
    public cliente(){
        try{
            Socket skCliente = new Socket (HOST, PUERTO);
            
            DataInputStream in = new DataInputStream(skCliente.getInputStream());
            DataOutputStream out = new DataOutputStream(skCliente.getOutputStream());
            
            Scanner param = new Scanner(System.in);
            Scanner sc = new Scanner(System.in);
            
            System.out.println(in.readUTF());
            String nombre, mensaje;
            boolean bandera = true;
            nombre = sc.nextLine();
            out.writeUTF(nombre);
            
            while(bandera){
                
                System.out.println("Servidor: " + in.readUTF());
                mensaje = sc.nextLine();
                out.writeUTF(mensaje);
                
                if(mensaje.equals("Bye")){
                    bandera = false;
                }
            }
            System.out.println(in.readUTF());
            skCliente.close();
        } catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    public static void main(String [] arg){
        new cliente();
    }
}