package editor;

import editor.Ambiente;

public class Editor {
    public Editor(){
    }
    public Entorno getEntorno(String nombreEntorno) {
        Entorno edificio = new Escenario(nombreEntorno);
        Entorno segundoPiso = new Escenario("segundo piso");
        ((Escenario) edificio).agregarEscenario((Escenario)segundoPiso);
        Ambiente aula1 = new Ambiente("aula1");
        Ambiente aula2 = new Ambiente("aula2");
        Ambiente aula3 = new Ambiente("aula3");
        Ambiente aula4 = new Ambiente("aula4");
        Ambiente aula5 = new Ambiente("aula5");
        Ambiente aula6 = new Ambiente("aula6");
        Ambiente pasillo = new Ambiente("pasillo");
        ((Escenario) segundoPiso).agregarEntorno(aula1);
        ((Escenario) segundoPiso).agregarEntorno(aula2);
        ((Escenario) segundoPiso).agregarEntorno(aula3);
        ((Escenario) segundoPiso).agregarEntorno(aula4);
        ((Escenario) segundoPiso).agregarEntorno(aula5);
        ((Escenario) segundoPiso).agregarEntorno(pasillo);
        conectarAmbientes(aula1,pasillo);
        conectarAmbientes(aula2,pasillo);
        conectarAmbientes(aula3,pasillo);
        conectarAmbientes(aula4,pasillo);
        conectarAmbientes(aula5,pasillo);
        conectarAmbientes(aula6,pasillo);
        return edificio;
    }
    public void conectarAmbientes(Ambiente amb1, Ambiente amb2){
        amb1.crearPuerta(amb2);
    }
}
