import numpy as np
import matplotlib.pyplot as plt
import math
from Figuras import *

class Principal:

    #b
    def __init__(self, height, width):
        self.height = height
        self.widht = width
        self.pixels = np.zeros((height, width, 3), dtype=np.uint8)
        self.figuras = []

    #b
    def agregarFigura(self, figura):
        self.figuras.append(figura)
        self.pintarPuntos(figura.puntosGraf, figura.color)

    #b
    def eliminarFigura(self, figura):
        self.pintarPuntos(figura.puntosGraf, [0,0,0])
        self.figuras.remove(figura)
        for f in self.figuras:
            self.pintarPuntos(f.puntosGraf, f.color)

    #b
    def trasladarFigura(self, figura, vector):
        self.pintarPuntos(figura.puntosGraf, [0,0,0])
        figura.trasladar(vector)
        self.pintarPuntos(figura.puntosGraf, figura.color)

    #b
    def rotarFigura(self, figura, puntoPivote, angulo):
        self.pintarPuntos(figura.puntosGraf, [0,0,0])
        figura.rotar(puntoPivote, angulo)
        self.pintarPuntos(figura.puntosGraf, figura.color)

    #b
    def escalarFigura(self, figura, sx, sy):
        self.pintarPuntos(figura.puntosGraf, [0,0,0])
        figura.escalar(sx, sy)
        self.pintarPuntos(figura.puntosGraf, figura.color)

    #b
    def escalarPivoteFigura(self, figura, sx, sy, puntoPivote):
        self.pintarPuntos(figura.puntosGraf, [0,0,0])
        figura.escalarPivote(sx, sy, puntoPivote)
        self.pintarPuntos(figura.puntosGraf, figura.color)

    #b
    def cambiarGrosorFigura(self, figura, grosor):
        self.pintarPuntos(figura.puntosGraf, [0,0,0])
        figura.cambiarGrosor(grosor)
        self.pintarPuntos(figura.puntosGraf, figura.color)

    #b
    def cambiarColorFigura(self, figura, color):
        figura.cambiarColor(color)
        self.pintarPuntos(figura.puntosGraf, figura.color)

    #b
    def pintarPuntos(self, puntos, color):
        for x, y in puntos:
            if 0 <= x < self.width and 0 <= y < self.height:
                self.pixels[x, y] = color

    #b
    def rellenar(self, punto, color, colorBorde):
            x, y = punto
            if not (0 <= x < self.pixels.shape[1] and 0 <= y < self.pixels.shape[0]):
                return

            if np.array_equal(self.pixels[y, x], colorBorde) or np.array_equal(self.pixels[y, x], color):
                return

            stack = [(x, y)]

            while stack:
                x, y = stack.pop()
                self.pixels[x, y] = color

                # Verificar y agregar píxeles vecinos si cumplen las condiciones
                neighbors = [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
                for nx, ny in neighbors:
                    if 0 <= nx < self.pixels.shape[0] and 0 <= ny < self.pixels.shape[1] and not np.array_equal(self.pixels[nx, ny], colorBorde) and not np.array_equal(self.pixels[nx, ny], color):
                        stack.append((nx, ny))

