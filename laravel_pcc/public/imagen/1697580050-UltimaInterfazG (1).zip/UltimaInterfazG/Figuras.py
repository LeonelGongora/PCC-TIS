from abc import ABC, abstractmethod
import math

class Figura(ABC):
    
    def __init__(self):
        self.puntosOrig = []  # Puntos que forman la figura
        self.puntosGraf = []  # Los puntos que se van a graficar
        self.color = []  # Codigo del color de la figura
    
    def bresenham_line(self, p1, p2):
        x0, y0 = p1
        x1, y1 = p2
        puntosLinea = []
        dx = abs(x1 - x0)
        dy = abs(y1 - y0)
        sx = 1 if x0 < x1 else -1
        sy = 1 if y0 < y1 else -1
        err = dx - dy

        while x0 != x1 or y0 != y1:
            puntosLinea.append((x0, y0))
            e2 = 2 * err
            if e2 > -dy:
                err -= dy
                x0 += sx
            if e2 < dx:
                err += dx
                y0 += sy

        puntosLinea.append((x1, y1))
        return puntosLinea
    
    def generarPuntos(self):
        pass

    def trasladar(self, vector):
        nuevosPuntos = []
        for x1, y1 in self.puntosOrig:
            x2, y2 = vector
            nueX = x1 + x2
            nueY = y1 + y2
            nuevosPuntos.append((nueX, nueY))

        self.puntosOrig = nuevosPuntos
        self.puntosGraf = nuevosPuntos

    def rotar(self, puntoPivote, angulo):
        nuevosPuntos = []
        for x1, y1 in self.puntosOrig:
            x2, y2 = puntoPivote
            nueX = round(x2 + (x1-x2)*math.cos(math.radians(angulo)) - (y1-y2)*math.sin(math.radians(angulo)))
            nueY = round(y2 + (x1-x2)*math.sin(math.radians(angulo)) + (y1-y2)*math.cos(math.radians(angulo)))
            nuevosPuntos.append((nueX, nueY))

        self.puntosOrig = nuevosPuntos
        self.puntosGraf = nuevosPuntos

    def cambiarGrosor(self, grosor):
        nuevosPuntos = []
        for x, y in self.puntosOrig:
            for dx in range(-grosor // 2, grosor // 2 + 1):
                for dy in range(-grosor // 2, grosor // 2 + 1):
                    nuevosPuntos.append((round(x + dx), round(y + dy)))
        self.puntosGraf = nuevosPuntos

    def cambiarColor(self, color):
        self.color = color

    def escalar(self, sx, sy):
        nuevosPuntos = []
        for x, y in self.puntosOrig:
            nueX = round(x * sx)
            nueY = round(y * sy)
            nuevosPuntos.append((nueX,nueY))
        self.puntosOrig = nuevosPuntos
        self.puntosGraf = nuevosPuntos

    def escalarPivote(self, sx, sy, puntoPivote):
        nuevosPuntos = []
        for x1, y1 in self.puntosOrig:
            x2, y2 = puntoPivote
            nueX = round(x1 * sx + x2*(1-sx))
            nueY = round(y1 * sy + y2*(1-sy))
            nuevosPuntos.append((nueX,nueY))
        self.puntosOrig = nuevosPuntos
        self.puntosGraf = nuevosPuntos


class Rectangulo(Figura):

    def __init__(self, p1, p2):
        self.puntosOrig = self.generarPuntos(p1, p2)
        self.puntosGraf = self.generarPuntos(p1, p2)
        self.color = [255,255,255]


    def generarPuntos(self, p1, p2):
        (x1, y1) = p1
        (x2, y2) = p2
        x1, x2 = min(x1, x2), max(x1, x2)
        y1, y2 = min(y1, y2), max(y1, y2)
        p3 = (x1, y2)
        p4 = (x2, y1)

        line1 = self.bresenham_line(p1, p3)
        line2 = self.bresenham_line(p1, p4)
        line3 = self.bresenham_line(p3, p2)
        line4 = self.bresenham_line(p4, p2)

        rectangulo = line1 + line2 + line3 + line4
        return rectangulo


class Triangulo(Figura):

    def __init__(self, p1, p2, p3):
        self.puntosOrig = self.generarPuntos(p1, p2, p3)
        self.puntosGraf = self.generarPuntos(p1, p2, p3)
        self.color = [255,255,255]

    def generarPuntos(self, p1, p2, p3):
        linea1 = self.bresenham_line(p1, p2)
        linea2 = self.bresenham_line(p2, p3)
        linea3 = self.bresenham_line(p1, p3)

        triangulo = linea1 + linea2 + linea3
        return triangulo
    

class Circulo(Figura):

    def __init__(self, centro, radio):
        self.puntosOrig = self.generarPuntos(centro, radio)
        self.puntosGraf = self.generarPuntos(centro, radio)
        self.color = [255,255,255]

    def generarPuntos(self, centro, radio):
        x0, y0 = centro
        circulo = []
        x, y = radio, 0
        p = 1 - radio  # Valor de decisión inicial

        while x >= y:
            circulo.append((x0 + x, y0 + y))
            circulo.append((x0 - x, y0 + y))
            circulo.append((x0 - x, y0 - y))
            circulo.append((x0 + x, y0 - y))
            circulo.append((x0 + y, y0 + x))
            circulo.append((x0 - y, y0 + x))
            circulo.append((x0 - y, y0 - x))
            circulo.append((x0 + y, y0 - x))

            y += 1
            if p <= 0:
                p = p + 2*y + 1
            else:
                x -= 1
                p = p + 2*y - 2*x + 1
        return circulo

