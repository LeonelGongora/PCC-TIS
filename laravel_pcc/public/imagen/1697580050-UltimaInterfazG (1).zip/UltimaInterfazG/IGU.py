import numpy as np
import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
from tkinter.simpledialog import *
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from Principal import Principal
from Figuras import *

class GUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Editor de Figuras")
        
        self.principal = Principal(1080, 1920)  # Crear instancia de Principal
        self.figActu = None # Figura actual que se selecciona en la lista desplegable
        
        # Crear lienzo para Matplotlib
        self.figure = Figure(figsize=(1920/200, 1080/200), dpi=100)
        self.canvas = FigureCanvasTkAgg(self.figure, master=root)
        self.canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.NONE, expand=True)
        
        # Inicializar el lienzo con la matriz de píxeles
        self.image = self.figure.add_subplot(111)
        self.image.imshow(self.principal.pixels)
        self.image.axis('off')
        self.image.set_aspect('auto')
        
        marco = ttk.Frame(root)
        marco.pack(side=tk.LEFT, padx=10, pady=10)

        # Crear un cuadro de herramientas
        self.crearBotones()

        # Botones para crear figuras
        ttk.Button(marco, text="Crear Circulo    ", command=self.crearCirculo).grid(row=0, column=0, padx=5, pady=5)
        ttk.Button(marco, text="Crear Rectangulo ", command=self.crearRectangulo).grid(row=1, column=0, padx=5, pady=5)
        ttk.Button(marco, text="Crear Triangulo  ", command=self.crearTriangulo).grid(row=2, column=0, padx=5, pady=5)

    def crearBotones(self):
        marcoBotones = ttk.LabelFrame(self.root, text="Herramientas")
        marcoBotones.pack(side=tk.BOTTOM, padx=10, pady=10)

        # Lista desplegable para seleccionar una figura existente
        self.selected_figure = tk.IntVar()
        # self.figActu = self.principal.figuras[self.seleccionado.get() - 1]
        self.figure_options = ttk.Combobox(marcoBotones, textvariable=self.selected_figure, state="readonly")
        self.actualizarListaFigs()  # Actualiza la lista desplegable con figuras existentes
        self.figure_options.grid(row=1, column=0, columnspan=3, padx=5, pady=5)
        
        # Botones para operaciones en la figura seleccionada
        ttk.Button(marcoBotones, text="Trasladar", command=self.trasladarFigura).grid(row=2, column=0, padx=5, pady=5)
        ttk.Button(marcoBotones, text="Rotar", command=self.rotarFigura).grid(row=2, column=1, padx=5, pady=5)
        ttk.Button(marcoBotones, text="Ecalar", command=self.escalarFigura).grid(row=2, column=2, padx=5, pady=5)
        ttk.Button(marcoBotones, text="Ecalar(Con pivote)", command=self.escalarPivoteFigura).grid(row=2, column=3, padx=5, pady=5)
        ttk.Button(marcoBotones, text="Cambiar Color", command=self.cambiarColor).grid(row=2, column=4, padx=5, pady=5)
        ttk.Button(marcoBotones, text="Cambiar Grosor", command=self.trasladarFigura).grid(row=3, column=0, padx=5, pady=5)
        ttk.Button(marcoBotones, text="Guardar Figura", command=self.rotarFigura).grid(row=3, column=1, padx=5, pady=5)
        ttk.Button(marcoBotones, text="Eliminar Figura", command=self.escalarFigura).grid(row=3, column=2, padx=5, pady=5)
        ttk.Button(marcoBotones, text="Linea Punteada", command=self.escalarPivoteFigura).grid(row=3, column=3, padx=5, pady=5)

    def actualizarListaFigs(self):
        # Obtener la cantidad de figuras
        num_figuras = len(self.principal.figuras)
            
        # Crear una lista de valores enteros del 1 al número de figuras
        valores_enteros = list(range(1, num_figuras + 1))
            
        # Actualiza la lista desplegable con valores enteros
        self.figure_options['values'] = valores_enteros
        self.figure_options.set("")  # Limpia la selección
    
    def crearCirculo(self):
        # Solicitar los puntos para el triángulo
        prompt = f"Ingrese el centro (x, y):"
        punto = askstring("Crear Circulo", prompt)
        if punto is None:
            # El usuario canceló la entrada
            return
        try:
            x, y = map(int, punto.split(","))
            punto = (x, y)
        except ValueError:
            messagebox.showerror("Error", "Ingrese coordenadas válidas (x, y)")
            return
        
        prompt_radio = "Ingrese el radio del círculo:"
        radio = askinteger("Crear Círculo", prompt_radio)
        if radio is None:
            # El usuario canceló la entrada
            return
        
        circulo = Circulo(punto, radio)
        self.principal.agregarFigura(circulo)
        self.mostrarMatriz()

        # Actualizar la lista de figuras
        self.actualizarListaFigs()

    def crearRectangulo(self):
        # Solicitar los puntos para el rectangulo
        puntos = []
        for i in range(2):
            prompt = f"Ingrese el punto {i + 1} (x, y):"
            punto = askstring("Trasladar", prompt)
            if punto is None:
                # El usuario canceló la entrada
                return
            try:
                x, y = map(int, punto.split(","))
                puntos.append((x, y))
            except ValueError:
                messagebox.showerror("Error", "Ingrese coordenadas válidas (x, y)")
                return
            
        rectangulo = Rectangulo(*puntos)
        self.principal.agregarFigura(rectangulo)
        self.mostrarMatriz()

        # Actualizar la lista de figuras
        self.actualizarListaFigs()

    def crearTriangulo(self):
        # Solicitar los puntos para el triángulo
        puntos = []
        for i in range(3):
            prompt = f"Ingrese el punto {i + 1} (x, y):"
            punto = askstring("Crear Triangulo", prompt)
            if punto is None:
                # El usuario canceló la entrada
                return
            try:
                x, y = map(int, punto.split(","))
                puntos.append((x, y))
            except ValueError:
                messagebox.showerror("Error", "Ingrese coordenadas válidas (x, y)")
                return
            
        triangulo = Triangulo(*puntos)
        self.principal.agregarFigura(triangulo)
        self.mostrarMatriz()

        # Actualizar la lista de figuras
        self.actualizarListaFigs()

    def trasladarFigura(self):
        prompt = f"Ingrese el vector (x, y):"
        punto = askstring("Crear Circulo", prompt)
        if punto is None:
            # El usuario canceló la entrada
            return
        try:
            x, y = map(int, punto.split(","))
            vector = (x, y)
        except ValueError:
            messagebox.showerror("Error", "Ingrese vector valido (x, y)")
            return
        
        self.principal.trasladarFigura(self.principal.figuras[0], vector)
        self.mostrarMatriz()
        

    def rotarFigura(self):
        prompt = f"Ingrese el punto pivote (x, y):"
        punto = askstring("Rotar", prompt)
        if punto is None:
            # El usuario canceló la entrada
            return
        try:
            x, y = map(int, punto.split(","))
            punto = (x, y)
        except ValueError:
            messagebox.showerror("Error", "Ingrese coordenadas válidas (x, y)")
            return
        
        prompt_angulo = "Ingrese el angulo:"
        angulo = askinteger("Rotar", prompt_angulo)
        if angulo is None:
            # El usuario canceló la entrada
            return
        
        self.principal.rotarFigura(self.principal.figuras[0], punto, angulo)
        self.mostrarMatriz()

    def escalarFigura(self):
        prompt_sx = "Ingrese el sx:"
        sx = askfloat("Escalar", prompt_sx)
        if sx is None:
            # El usuario canceló la entrada
            return
        
        prompt_sy = "Ingrese el sy:"
        sy = askfloat("Escalar", prompt_sy)
        if sy is None:
            # El usuario canceló la entrada
            return
        
        self.principal.escalarFigura(self.principal.figuras[0], sx, sy)
        self.mostrarMatriz()

    def escalarPivoteFigura(self):
        prompt_sx = "Ingrese el sx:"
        sx = askfloat("Ecalar(Con pivote)", prompt_sx)
        if sx is None:
            # El usuario canceló la entrada
            return
        
        prompt_sy = "Ingrese el sy:"
        sy = askfloat("Ecalar(Con pivote)", prompt_sy)
        if sy is None:
            # El usuario canceló la entrada
            return
        
        prompt = f"Ingrese el punto pivote (x, y):"
        punto = askstring("Ecalar(Con pivote)", prompt)
        if punto is None:
            # El usuario canceló la entrada
            return
        try:
            x, y = map(int, punto.split(","))
            punto = (x, y)
        except ValueError:
            messagebox.showerror("Error", "Ingrese coordenadas válidas (x, y)")
            return
        
        self.principal.escalarPivoteFigura(self.principal.figuras[0], sx, sy, punto)
        self.mostrarMatriz()

    def cambiarColor(self):
        prompt = f"Ingrese el código del color (R, G, B):"
        color = askstring("Cambiar Color", prompt)
        if color is None:
            # El usuario canceló la entrada
            return
        try:
            R, G, B = map(int, color.split(","))
            if 0 <= R <= 255 and 0 <= G <= 255 and 0 <= B <= 255:
                # Los valores están en el rango válido
                color = [R, G, B]
            else:
                messagebox.showerror("Error", "Los valores deben estar en el rango de 0 a 255")
                return
        except ValueError:
            messagebox.showerror("Error", "Ingrese un color válido en el formato [R, G, B]")
            return
        
        self.principal.cambiarColorFigura(self.principal.figuras[0], color)
        self.mostrarMatriz()

    def cambiarGrosor(self):
        # preguntar si figActu != None
        # recopilar datos [0,0,0] 2,2,2
        # usar metodo rotar en principal con la figActu
        # mostrar matriz
        pass

    def lineaPunteada(self):
        # preguntar si figActu != None
        # recopilar datos [0,0,0] 2,2,2
        # usar metodo rotar en principal con la figActu
        # mostrar matriz
        pass

    def guardarImagen(self):
        # preguntar si figActu != None
        # recopilar datos [0,0,0] 2,2,2
        # usar metodo rotar en principal con la figActu
        # mostrar matriz
        pass

    def eliminarFigura(self):
        self.principal.eliminarFigura(self.figActu)
        self.figActu = None
        self.actualizarListaFigs()
        self.mostrarMatriz()


    def mostrarMatriz(self):
        self.image.imshow(self.principal.pixels)
        self.canvas.draw()

if __name__ == "__main__":
    root = tk.Tk()
    gui = GUI(root)
    root.mainloop()

