package juego.editor;

public class Editor {

    public Entorno getEntorno() {
        return getEscenarioDePrueba();
    }

    public Entorno getEscenarioDePrueba() {
        Escenario principal = new Escenario("Biblioteca");
        // Planta Baja
        Escenario plantaBaja = crearEscenario("PB", 4);
        principal.add(plantaBaja);
        // Planta 1
        Escenario planta1 = crearEscenario("P1", 0);
        principal.add(planta1);
        // Planta 2
        Escenario planta2 = crearEscenario("P2", 5);
        principal.add(planta2);
        // Conectar escenarios
        conectarEscenarios(plantaBaja, planta1);
        conectarEscenarios(planta1, planta2);

        return principal;
    }

    private Escenario crearEscenario(String nombre, int ambientes) {
        Escenario escenario = new Escenario(nombre);
        Ambiente pasillo = new Ambiente("Pasillo " + nombre);
        Puerta puertaAPasillo = new Puerta(pasillo);
        escenario.add(pasillo);
        for (int i = 1; i <= ambientes; i++) {
            Ambiente ambiente = new Ambiente("Aula " + i + " - " + nombre);
            ambiente.addElemento(puertaAPasillo);
            pasillo.addElemento(new Puerta(ambiente));
            escenario.add(ambiente);
        }
        return escenario;
    }

    private void conectarEscenarios(Escenario escenario1, Escenario escenario2) {
        Ambiente pasillo1 = escenario1.obtenerPasillo();
        Ambiente pasillo2 = escenario2.obtenerPasillo();
        pasillo1.addElemento(new Puerta(pasillo2));
        pasillo2.addElemento(new Puerta(pasillo1));
    }

}