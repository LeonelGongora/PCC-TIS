package juego.editor;
import java.util.*;
public  class Editor {
    private Escenario entorno;
    private Entorno entornos;
    public Editor(){
        Escenario edificioCAE = new Escenario("EdificioCae");
        Escenario segundoPiso = new Escenario("2doPiso");
        Ambiente ambiente1 = new Ambiente("692D");
        Ambiente ambiente2 = new Ambiente("Pasillo");
        Ambiente ambiente3 = new Ambiente("692C");
        Ambiente ambiente4 = new Ambiente("Laboratorio");
        Ambiente ambiente5 = new Ambiente("CAE");
        Escenario plantaBaja = new Escenario("Planta Baja");
        Ambiente ambiente8 = new Ambiente("Pasillo");
        Ambiente ambiente9 = new Ambiente("Biblioteca");
        Puerta puerta9 = new Puerta("Puerta9",ambiente9);
        Puerta puerta10 = new Puerta( "Puerta10",ambiente8);
        Puerta puerta1 = new Puerta("p1", ambiente2);
        Puerta puerta2 = new Puerta("p2",ambiente2);
        Puerta puerta3 = new Puerta("p3",ambiente2);
        Puerta puerta4 = new Puerta("p4",ambiente2);
        Puerta puerta5 = new Puerta("p5",ambiente1);
        Puerta puerta6 = new Puerta("p6",ambiente3);
        Puerta puerta7 = new Puerta("p7",ambiente4);
        Puerta puerta8 = new Puerta("p8",ambiente5);
        ambiente1.agregarElemento(puerta1);
        ambiente3.agregarElemento(puerta2);
        ambiente4.agregarElemento(puerta3);
        ambiente5.agregarElemento(puerta4);
        ambiente2.agregarElemento(puerta5);
        segundoPiso.agregarEntorno(ambiente1);
        segundoPiso.agregarEntorno(ambiente2);
        segundoPiso.agregarEntorno(ambiente3);
        segundoPiso.agregarEntorno(ambiente4);
        segundoPiso.agregarEntorno(ambiente5);
        ambiente8.agregarElemento( puerta9);
        ambiente9.addPuerta(puerta10);
        plantaBaja.agregarEntorno(ambiente8);
        plantaBaja.agregarEntorno(ambiente9);
        edificioCAE.agregarEntorno(segundoPiso);
        edificioCAE.agregarEntorno(plantaBaja);
        System.out.println("Escenarios:");
        entornos = edificioCAE;
    }

    public void agregarEntorno(Entorno entorno){
        // entornos.add(entorno);
    }
    public Entorno getEntorno() {
        return getEscenarioDePrueba();
        //return null;
    }

    public Entorno getEscenarioDePrueba() {
        //return null;
        return entornos;
    }

}
