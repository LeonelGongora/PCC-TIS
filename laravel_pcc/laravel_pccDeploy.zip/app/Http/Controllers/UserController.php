<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use LengthException;
use PhpParser\Node\Expr\Cast\String_;
use Ramsey\Uuid\Type\Integer;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return User::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function get(){

        $usuarios = User::all();
        return response()->json([
            'status' => 200,
            'message' => 'Usuarios obtenidos exitosamente',
            'usuarios' => $usuarios,

        ]);
    }

    public function getbyId($id){

        $usuario = User::find($id);
        return response()->json([
            'status' => 200,
            'message' => 'Usuario obtenido exitosamente',
            'usuario' => $usuario,

        ]);
    }

    public function store(Request $request)
    {
        $user = new User();
        $user-> nombre = $request -> nombre;
        $user-> apellido = $request -> apellido;
        $user-> ci = $request -> ci;
        $user-> pais = $request -> pais;
        $user-> telefono = $request -> telefono;
        $user-> email = $request -> email;
        $user-> password = $request -> password;
        $user-> auxinoti = 0;

        $user -> save();
        $user->id;

        return response()->json([
            'status' => 200,
            'message' => 'Usuario añadido exitosamente',
            'ultimo_id' => $user->id,
        ]);
    }

    public static function getIdbyDNI($numero_documento){
        $usuario = User::where('ci', $numero_documento)->first();

        if ($usuario) {
            return response()->json([
                'status' => 200,
                'message' => 'id obtenido exitosamente',
                'id_usuario' => $usuario->id,
                'nombre_usuario' => $usuario->nombre,
                'apellido_usuario' => $usuario->apellido,
                'contraseña_usuario' => $usuario->password,
            ]);
        }

        return null; // O puedes manejar el caso en el que no se encuentra el usuario
    }

    public function getUser1($event_id){
        
        return User::whereHas('events', function ($query) use ($event_id) {
            $query->where('event_id', $event_id)
                  ->where('solicitud', 1);
        })->get();
    }

    public function getUser01($event_id){
        
        return User::whereHas('events', function ($query) use ($event_id) {
            $query->where('event_id', $event_id)
                  ->where('solicitud', 0)
                  ->orWhere('solicitud', 1);
        })->get();
    }

    public function getCoachArray(Request $arreglo){
        
        $arr = $arreglo->arregloCoach;
        $arrResul = [];
        $aa=[];
        for ($i=0; $i < $arreglo->lonarr ; $i++) { 
            $coc = User::where('id', substr($arr, $i, 1))->get();
            array_push($arrResul, $coc[0]);
        }

        return $arrResul;


        // return User::whereHas('events', function ($query) use ($arreglo) {
        //     $query->where('event_id', $arreglo)
        //           ->where('solicitud', 0)
        //           ->orWhere('solicitud', 1);
        // })->get();
        // return $arreglo->lonarr;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return User::find($id);
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $user = User::find($id);
        if(!is_null($user)){
        $user->update($request->all());
        return $user;
       }  
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user=User::find($id);
        $user->delete();
    }
}