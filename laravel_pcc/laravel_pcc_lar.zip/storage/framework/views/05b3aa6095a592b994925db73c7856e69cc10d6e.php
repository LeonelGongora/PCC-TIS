
Saludos, su nueva contraseña de PCC es: <?php echo e($content); ?>




<?php /**PATH C:\Users\jmanu\OneDrive\Escritorio\PCC-develop\DeployUbuntu\PCC-TIS\laravel_pcc\resources\views/orden.blade.php ENDPATH**/ ?>